<footer>
    <p>Twittort — форум для тех, кто любит крысить<br>Версия: <a href="https://t.me/ecosorter_forum" target="_blank">2.3.0</a></p>
</footer>