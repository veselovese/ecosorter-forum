<footer>
    <p>Twittort — форум для тех, кто любит крысить<br>Версия: <a href="https://t.me/ecosorter_forum" target="_blank">2.1.1</a></p>
</footer>