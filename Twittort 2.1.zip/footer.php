<footer>
    <p>Twittort — форум для тех, кто любит крысить<br>Версия: <a href="https://t.me/ecosorter_forum">2.1</a></p>
</footer>