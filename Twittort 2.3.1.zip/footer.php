<footer>
    <p>Twittort — форум для тех, кто зашёл на форум<br>Версия: <a href="https://t.me/ecosorter_forum" target="_blank">2.3.1</a></p>
</footer>