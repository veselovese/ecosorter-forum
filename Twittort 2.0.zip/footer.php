<footer>
    <p>Twittort — форум для тех, кто любит крысить<br>Версия: <a href="https://t.me/ecosorter_forum">2.0</a></p>
</footer>